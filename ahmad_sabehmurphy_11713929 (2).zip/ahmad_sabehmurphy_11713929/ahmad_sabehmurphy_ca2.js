//Part 1 a)
//query showing all movies staring mathew mcconauhey and kate hudson
//results  show the title, year and cast by showing the most recent film
db.movies.find(
    {cast: {$in: ["Matthew McConauhey", "Kate Hudson"]}},
    {_id:0, title:1, year:1, cast:1}
).sort({year:-1}).pretty()


//Part 1 b)
//show titles of movies with imdb rating>9 and RT >4
//sorting based on imdb rating showing in descending order 
//limit is set to top 5 results to show the first 3 films in the intended order
  db.movies.find(
      {$and:[
          {"imdb.rating": {$gt: 9}},
          { $or: [{"tomatoes.viewer.rating": {$gt: 4}},
                    {"tomatoes.rotten": {$gt:4}}]}
          ]},
      {_id:0, title:1}
  ).sort({"imdb.rating":-1}).limit(5).pretty()
  
//Part 1 c)
//films where comedy is one of the genres, rating is G or PG
//imdb rating is 8 or more/top 5 results to show all movies in 
db.movies.find(
    { $and:[
        {genres:"Comedy"},
        {"imdb.rating": {$gte:8}},
        { $or: [{rated:"G"}, {rated: "PG"}]}
    
    ]},
    { _id:0, title:1, imdb:1, genres:1}
).sort({"imdb.rating":-1}).limit(5).pretty()

//Part 1 d)
// counting how many movies cercei lannister commented on since feb 2016
// if the ISODate used is january 2015 then i get a result of 45

db.movies.find(
    { $and: [
        {"comments.name": "Cersei Lannister"},
        {"comments.date": {"$gt": ISODate("2016-02-11T01:00:00Z")}}
    ]},
    { _id:0, title:1}
).count()

//elemMatch way

db.movies.find(
    { $and: [
    {
      comments: {
        $elemMatch: {
            // email:"lena_headey@gameofthron.es",
            name: "Cersei Lannister"
        }
      }
    },
      {"comments.date":{$gte: ISODate("2015-01-01T00:00:00Z")}}

]},
    {_id:0, title:1}
).count()


//maybe this way?
db.movies.find(
    {$and:[
        {comments: {
          $elemMatch: {
              // email:"lena_headey@gameofthron.es",
              "name": ["Cersei Lannister"]
          }
        }
    },{"comments.date":{$gte: ISODate("2015-01-01T00:00:00Z")}}
    ]  },{ _id:0, title:1}  ).count()


// what is the release date  of comedy movies with imdb ratings above 7 does cersei comment on 

db.movies.find(
    { $and: [
        {"comments.name": "Cersei Lannister"},
        {"imdb.rating": {$gte:7}},
        {genres:"Comedy"}
    ]},
    { _id:0, title:1, imdb:1, genres:1, released:1}
).pretty()

//what are the movie genres of films with imdb rating of 6 or more and less than 10 votes on the site
db.movies.find({
    $and: [
        {"imdb.rating": {$gte:6}},
        {"imdb.votes": {$lte:10}},
    ]
},
    {  _id:0, title:1, genres:1}
).pretty()

// What are the highest rated non english films with imdb rating of 9 and above
db.movies.find(
   { $and: [
        {"imdb.rating": {$gte:9}},
        {languages: {$nin:["English"]}}
    ]
},
    {  _id:0, title:1, languages:1}
).pretty()

// What tom green movie did hodor comment on
db.movies.find(
    { $and: [
    {
      comments: {
        $elemMatch: {
              email: "kristian_nairn@gameofthron.es",
        }
      }
    },
    {cast: {$in: ["Tom Green"]}}

]},
    {_id:0, title:1}
)

//all thriller movies made in germany
db.movies.find(
    { $and: [
    {countries: {$all:["Germany"]}},
    {genres: {$in:["Thriller"]}}
     ]},
     {_id:0, title:1}
).pretty()

//How many matthew McConauhey  and kate hudson movies are above imdb rating of 6
db.movies.find(
    { $and: [
    {cast: {$in: ["Matthew McConauhey", "Kate Hudson"]}},
    {"imdb.rating": { $gte:6}}
    ]}
).count()

//Part 2
//Adding 5 movies from 2017 and 2020
db.movies.insertMany([
//1st movie
    {   
        "_id":9999001,
        "title": "Wonder Woman",
        "year":2017,
        "runtime":106,
        "cast":[" Gal Gadot"," Chris Pine"," Robin Wright"],
        "plot":"When a pilot crashes and tells of conflict in the outside world, Diana, an Amazonian warrior in training, leaves home to fight a war, discovering her full powers and true destiny.",
        "directors":["Patty Jenkins"],
        "imdb":{"rating":7.4,"votes":560411},
        "genre":["Action","Adventure","Fantasy"]
    },
//2nd movie
    {
        "_id":9999002,
        "title": "Dunkirk",
        "year":2017,
        "runtime":106,
        "cast":[" Fionn Whitehead"," Barry Keoghan"," Robin WrMark Rylance"],
        "plot":"Allied soldiers from Belgium, the British Empire, and France are surrounded by the German Army and evacuated during a fierce battle in World War II.",
        "directors":["Christopher Nolan"],
        "imdb":{"rating":7.8,"votes":551372},
        "genre":["Action","Drama","History"]
    },
//3rd movie
    {   
        "_id":9999003,
        "title": "Justice League",
        "year":2017,
        "runtime":120,
        "cast":[" Gal Gadot"," Ben Affleck"," Jason Momoa"],
        "plot":"Fueled by his restored faith in humanity and inspired by Superman's selfless act, Bruce Wayne enlists the help of his new-found ally, Diana Prince, to face an even greater enemy.",
        "directors":["Zack Snyder"],
        "imdb":{"rating":6.3,"votes":382708},
        "genre":["Action","Adventure","Fantasy"]
    },
//4th movie
    {
        "_id":9999004,
        "title": "Spider-Man: Homecoming",
        "year":2017,
        "runtime":133,
        "cast":[" Tom Holland"," Michael Keaton"," Robert Downey Jr."],
        "plot":"Peter Parker balances his life as an ordinary high school student in Queens with his superhero alter-ego Spider-Man, and finds himself on the trail of a new menace prowling the skies of New York City.",
        "directors":["Jon Watts"],
        "imdb":{"rating":7.4,"votes":509404},
        "genre":["Action","Adventure","Sci-Fi"]
    },
//5th movie
    {
        "_id":9999005,
        "title": "Thor: Ragnarok ",
        "year":2017,
        "runtime":130,
        "cast":[" Chris Hemsworth"," Tom Hiddleston"," Cate Blanchett"],
        "plot":"Imprisoned on the planet Sakaar, Thor must race against time to return to Asgard and stop Ragnarök, the destruction of his world, at the hands of the powerful and ruthless villain Hela.",
        "directors":["Taika Waititi"],
        "imdb":{"rating":7.9,"votes":583563},
        "genre":["Action","Adventure","Comedy"]
    }
]);

//Part 3 a)
//adding a cast member to the justice league cast array
db.movies.updateOne(
    {_id:9999003},
    {$push: {cast: "Henry Cavill"}}
)

// Part 3 b)
//update imdb rating of justice league
//increase number of votes by one
db.movies.updateOne(
    {_id: 9999003},
    { $set:{
        "imdb.rating":8,
        "imdb.votes":382709,
    }}
)

//Part 3 c)
//add comments subdocument to the Dunkirk Document
//add rt subdocument
db.movies.updateOne(
    { _id: 9999002},
    {
        $set: {
            "tomatoes" : {
                "viewer" : {
                        "rating" : 3.8,
                        "numReviews" : 321,
                        "meter" : 80
                },
                "dvd" : ISODate("2005-07-19T00:00:00Z"),      
                "lastUpdated" : ISODate("2015-07-29T19:31:24Z")
        },
        "num_mflix_comments" : 3,
        "comments" : [
                {
                        "name" : "Pamela Ferguson",
                        "email" : "pamela_ferguson@fakegmail.com",
                        "movie_id" : 11110001,
                        "text" : "Sequi maxime laborum doloremque earum delectus odio exercitationem. Accusamus repudiandae earum soluta quos. Culpa totam illo laborum.",
                        "date" : ISODate("2016-02-13T09:15:29Z")
                }
        ]}
    },
    { upsert: true }
)

//Part 4
 db.movies.find({title:"Wonder Woman"}).pretty()
 //to find the _id// When I ran the script I gave a unique _id of 9999001
//Deleting the Wonder Woman movie document
db.movies.deleteOne({_id: 9999001})
//to check if wonder woman movie is deleted
db.movies.find({title:"Wonder Woman"}).pretty()
//to drop current database
db.dropDatabase()