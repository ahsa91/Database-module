#remember  to add foreign keys and order  of tables
-- -----------------------------------------------------
-- Drop the 'platDon' database/schema
-- -----------------------------------------------------

DROP SCHEMA IF EXISTS platDon;

-- -----------------------------------------------------
-- Create 'platDon' database/schema and use this database
-- -----------------------------------------------------


CREATE SCHEMA IF NOT EXISTS platDon;

use platDon;

-- create staff table
create table staff(
staffId varchar(4) not null,
sName varchar(20) not null,
salary varchar(6) not null,
branchNo varchar(3) not null,
mgrNo varchar(3),
suNo varchar(3),
primary key (staffId)
);

-- adding values into staff table
insert into staff values
('1', 'Ned Flanders', '70000', '1','n/a','1'),
('2', 'Millhouse Van Houten', '24000', '1', '9', 'n/a'),
('3', 'Kent Brockman', '150000', '1','2','n/a'),
('4', 'Moe Szyslak', '5000', '1', 'n/a','3'),
('5', 'Nelson Muntz', '300000', '21', '1','n/a'),
('6', 'Carl Carlson', '200000', '5', 'n/a','n/a'),
('7', 'Fat Tony Damico', '900000', '3', 'n/a','n/a'),
('8', 'Timothy Lovejoy', '40000', '11', 'n/a','n/a'),
('9', 'Maude Flanders', '70000', '12', 'n/a','n/a'),
('10', 'Agnes Skinner', '80000', '13', 'n/a','n/a');

select * from staff; 

-- create supplier table
create table supplier (
supId varchar(5) not null,
supName varchar(20) not null,
medEq varchar(20) not null,
branchNo varchar(3) not null,
primary key (supId)
);



-- insert into supplier values
insert into supplier values
('1','CO19 MEDICAL','SYRINGES','1'),
('2','HARRIS MEDICAL','SYRINGES','1'),
('3','MURPHY MEDICAL','MASKS','002'),
('4','GERMAN MEDICAL','COAGULATOR','4'),
('5','CROATIAN MEDICAL','PIPETTES','10'),
('6','SALHI MEDICAL','IV DRIPS','40');

 select * from supplier;
-- create donation table

create table donation (
smpId varchar(9) not null,
patientId varchar(9) not null,
branchNo varchar(3) not null,
hospId varchar(6) not null,
primary key (smpId)
);

-- insert values into donation table
insert into donation values
('1', '1', '1', '1'),
('2', '2', '1', '1'),
('3', '3', '1', '1'),
('4', '4', '1', '1'),
('5', '5', '21', '2'),
('6', '6', '5', '3'),
('7', '7', '3', '3'),
('8', '8', '11', '10'),
('9', '9', '12', '12'),
('10', '10', '13', '100032');

-- select * from donation;

create table donor(
donorId varchar(5) not null,
donorName varchar(20)  not null,
branchNo varchar(3) not null,
bloodGrp varchar(3) not null,
medRep varchar(20) not null,
address varchar(30) not null,
contactNumber varchar(10) not null,
smpId varchar(9) not null,
primary key (donorId),
constraint fk_smpId foreign key (smpId) references donation(smpId)
on update cascade on delete cascade
);

-- insert values into donor
insert into donor values
('1', 'homer simpson', '1', 'AB+', 'Asymptomatic', 'springfield', '0870634332', '1'),
('2', 'marge simpson', '1', 'A+', 'Asymptomatic', 'springfield', '0870635332', '2'),
('3', 'lisa simpson', '1', 'AB+', 'Asymptomatic', 'springfield ', '0870664332', '3'),
('4', 'barney Gumble', '1', 'O-', 'no sense of taste', ' springfield ', '0860634332', '4'),
('5', 'monty burns', '21', 'B+', 'no sense of smell', ' waterford ', '0850634332', '5'),
('6', 'seymor skinner', '5', 'B-', 'breathing problems', 'kildare', '0870634532', '6'),
('7', 'waylon smithers', '3', 'A+', 'Asymptomatic', 'belfast', '0870634932', '7'),
('8', 'patty bouvier', '11', 'A-', 'no sense of smell', ' dublin', '0870632332', '8'),
('9', 'lenny leonard', '12', 'AB-', 'breathing problems', ' galway', '0870634339', '9'),
('10032', 'martin prince', '13', 'AB+', 'breathing problems', ' kilkenny', '0897772212', '10');

 select * from donor;



-- show tables;

-- create hospital table
create table hospital (
adDate date,
hospId varchar(6) not null,
patientId varchar(9) not null,
branchNo varchar(3) not null,
smpId varchar(9) not null,
hospName varchar(30) not null,
primary key (adDate)
);

-- insert values into hospital
insert into hospital values
('2020-03-09','1', '1', '1', '1', ' Springfield Hospital'),
('2020-04-10','1', '2', '1', '2', ' Springfield Hospital'),
('2020-05-11','1', '3', '1', '3', ' Springfield Hospital'),
('2020-06-03','1', '4', '1', '4', ' Springfield Hospital'),
('2020-02-12','2', '5', '21', '5', ' Waterford Hospital'),
('2020-05-05','3', '6', '5', '6', ' Kildare Hospital'),
('2020-07-01','3', '7', '3', '7', ' Belfast Hospital'),
('2020-08-02','10', '8', '11', '8', ' Dublin Hospital'),
('2020-06-06','12', '9', '12', '9', ' Galway Hospital'),
('2020-07-07','100032', '10', '13', '10', ' Kilkenny Hospital');

select * from hospital;

-- create patient table
create table patient (
patientId varchar(9) not null,
adDate date,
hospId varchar(6) not null,
branchNo varchar(3) not null,
smpId varchar(9) not null,
hospName varchar(30) not null,
bloodGrp varchar(3) not null,
disease varchar(10) not null,
medReport varchar(20) not null,
primary key (patientId),
constraint fk_adDate foreign key (adDate) references hospital(adDate)
on update cascade on delete cascade 
);

-- enter values into patient table
insert into patient values
('1', '2020-03-09', '1', '1', '1', 'Springfield Hospital', 'O+', 'COVID 19', 'breathing problems'),
('2', '2020-04-10', '1', '1', '1', 'Springfield Hospital', 'AB+', 'COVID 19', 'breathing problems'),
('3', '2020-05-11', '1', '1', '1', 'Springfield Hospital', 'A-', 'COVID 19', 'breathing problems'),
('4', '2020-06-03', '1', '1', '1', 'Springfield Hospital', 'B-', 'COVID 19', 'breathing problems'),
('5', '2020-02-12', '2', '21','21', 'Waterford Hospital', 'AB+', 'COVID 19', 'no taste'),
('6', '2020-05-05', '3', '5','5', 'Kildare Hospital', 'O-', 'COVID 19', 'no taste'),
('7', '2020-07-01', '3', '3','3', 'Belfast Hospital', 'AB-', 'COVID 19', 'no smell'),
('8', '2020-08-02', '10', '11','11', 'Dublin Hospital', 'A+', 'COVID 19', 'no smell'),
('9', '2020-06-06', '12', '11','12', ' Galway Hospital', 'B+', 'COVID 19', 'cough'),
('10', '2020-07-07', '100032', '12', '10', 'Kilkenny Hospital', 'AB-', 'COVID 19', 'cough');

select * from patient;

-- create table for Bloodbank

create table bloodbank (
branchNo varchar(3) not null,
patientId varchar(9) not null,
adDate date not null,
hospId varchar(6) not null,
supId varchar(5) not null,
smpId varchar(9) not null,
staffId varchar(4),
donorId varchar(5) not null, -- remember to fill
primary key (branchNo),
constraint fk_pateientId foreign key(patientId) references patient(patientId) on update cascade on delete cascade,
-- using fkbld_ as the first part of the variable declaring the foriegn keys in the bloodbank table to avoid duplicate error
constraint fkbld_adDate foreign key (adDate) references hospital(adDate) on update cascade on delete cascade,
constraint fk_supId foreign key (supId) references supplier (supId) on update cascade on delete cascade,
constraint fkbld_smpId foreign key (smpId) references  donation(smpId) on update cascade on delete cascade,
constraint fk_staffId foreign key (staffId) references staff(staffId) on update cascade on delete cascade,
constraint fk_donorId foreign key (donorId) references donor(donorId) on update cascade on delete cascade
);
-- insert into bloodbank values
insert into bloodbank values
('1', '1', '2020-03-09', '1', '1', '1', '1', '1'),
('21', '5', '2020-02-12', '2', '4', '5', '5','2'),
('5', '6', '2020-05-05', '3', '1', '6', '6', '3'),
('3', '7', '2020-07-01', '3', '2', '7', '7', '4'),
('11', '8', '2020-08-02', '10', '5' , '8', '8', '5'),
('12', '9', '2020-06-06', '12', '6', '9', '9', '10032'),
('13', '10', '2020-07-07', '100032', '6', '10', '10', '7');

select * from bloodbank;

-- triggers
-- -------------------------------
-- trigger that logs changes to the staff table
create table staff_audit (
id int auto_increment,
staffId varchar(4) not null,
sName varchar(20) not null,
salary varchar(6) not null,
branchNo varchar(3) not null,
mgrNo varchar(3),
suNo varchar(3),
changedate datetime default null,
action VARCHAR(50) DEFAULT NULL,
primary key (id)
);
 -- checking staff_audit table is created 
select * from staff_audit;

delimiter $$
create trigger before_staff_audit
	before update on staff
	for each row
begin
	insert into staff_audit
    set action = 'update',
		staffId= old.staffId,
        sName = old.sName,
        salary = old.salary,
        branchNo = old.branchNo,
        mgrNo = old.mgrNo,
        suNo = old.suNo,
        changedate = now();
end $$
delimiter ;

select * from staff;

-- updating maude flanders name to her son Tod
update staff
set sName= "Tod"
where sName like '%maude%';

-- checking if change is made 
select * from staff;
-- checking if trigger worked
select * from staff_audit;
-- show the trigger details
show triggers;

-- index
-- create index of patients with  admission dates in descending order
create index addmissiondate on patient(adDate desc);
show index from  patient;

-- create index of donors names alphabetically in descending order
create index donorNames on donor(donorName desc);
show index from donor;

-- views
-- create view to  list the name of hospitals and date of admission of patients to Springfield hospital
create view hospAdmSpring as
	select hospName as 'Hospital Name', adDate  as 'Admission Date' 
    from patient
    where hospName like '%springfield%' ;
-- show the view
select * from hospAdmSpring;

-- create view showing patient ID, sample ID with medical report and name of donor along with which bloodbank branch the sample was donated
create view smplChain as
	select patient.patientId, patient.branchNo, donor.donorId, donor.medRep as 'Donor Medical report', donorName as 'Donor Name'
	from bloodbank join patient
	on patient.patientId = bloodbank.patientId
	join donor
	on bloodbank.donorId = donor.donorId;

-- show view
select * from smplChain;

drop view smplChain;
