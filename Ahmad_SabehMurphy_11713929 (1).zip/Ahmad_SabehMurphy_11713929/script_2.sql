use platDon;

-- join 1
-- table showing patientID, blood type, breathing problems, and values of assymptomatic donors and their nnames

select  distinct patient.patientId, patient.bloodGrp as 'Patient Blood Group', patient.medReport as 'Patient Medical Report',
donorName as 'Donor Name', donor.medRep as 'Donor Medical Report'
from patient join donor
on patient.smpId = donor.smpId
where patient.medReport like '%breathing%';


-- join 2
-- right outer join
-- in a hypothetical scenario where one of the patients contracted HIV and died we need information
-- on supplier equipment because of contamination fear
select distinct *
from patient right join supplier
on patient.branchNo = supplier.branchNo
where patient.patientId like '1';

-- what is the average salary of staff employees?
select avg(salary) as 'Average salary of employees in blood Banks'
from staff;

-- subquery 1
select count(staffId) as 'number of employees earning above average salary'
from staff
where salary > (select avg(salary) from staff );


-- subquery 2
select staffId, sName as 'employees earning above average salary', salary
from staff
where salary > (select avg(salary) from staff );



-- subquery 3 using IN
-- how many patients have donors from the simpson family
select count(patientId) as 'number of patients given simpson family samples'
from patient
where smpId in
	(select smpId
    from donor
    where donorName like '%simpson%');
    
-- subquery 4 using ALL
-- finding the details of employees who make more than 40k pa 
-- using ALL
select staffId, sName as 'Staff member name', salary
from staff
where salary > all
		(select  salary
        from staff
        where salary < 40000);

-- Creates user and grants appropriate privileges to those user
-- im creating a user called manager and another called Hospital Admin

create user Manager identified by 'manager';
-- 
create user HospAdmin identified by 'Hospital Admin';
-- grant privileges to Manager on all tables within platDon schema
grant insert, update, delete, select on bloodbank to Manager;
grant insert, update, delete, select on supplier to Manager;
-- grant privelges to hospAdmin
grant insert, update, select on hospital to HospAdmin;

